package com.MyProject.JobListing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JobListingApplicationTests {

	@Test
	void contextLoads() {
	}

}
