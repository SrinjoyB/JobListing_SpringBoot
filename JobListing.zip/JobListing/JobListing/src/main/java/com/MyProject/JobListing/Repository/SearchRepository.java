package com.MyProject.JobListing.Repository;

import com.MyProject.JobListing.Models.Post;

import java.util.List;

public interface SearchRepository {

    List<Post> findByText(String text);

}
