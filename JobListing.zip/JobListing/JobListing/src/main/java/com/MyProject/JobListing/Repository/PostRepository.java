package com.MyProject.JobListing.Repository;

import com.MyProject.JobListing.Models.Post;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface PostRepository extends MongoRepository<Post,String>
{

}